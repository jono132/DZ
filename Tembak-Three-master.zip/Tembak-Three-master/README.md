"# Tembak-Three"<br>
=========================================
 * Name:    Dor Three beta
 * Author:  Satria Wibawa
 * FB: https://www.facebook.com/HTTP200K
 * Github: https://github.com/satriawibawa
 * Created:  31/08/2018<br><br>

========================================
Link Dor: http://satriawibawa.rocketnesia.host/3/.
========================================
